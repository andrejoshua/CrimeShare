package com.example.andrena70.crimeshare;

import android.app.Activity;
import android.os.Bundle;

public class RateAppActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate_app);
    }
}
